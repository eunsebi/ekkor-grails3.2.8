package xyz.ekkor

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class LoggedInSpec extends Specification implements DomainUnitTest<LoggedIn> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
