package xyz.ekkor

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class CustomUserDetailServiceSpec extends Specification implements ServiceUnitTest<CustomUserDetailService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
