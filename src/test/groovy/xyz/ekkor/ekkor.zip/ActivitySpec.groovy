package xyz.ekkor

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ActivitySpec extends Specification implements DomainUnitTest<Activity> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
