package xyz.ekkor

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ArticleNoticeSpec extends Specification implements DomainUnitTest<ArticleNotice> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
