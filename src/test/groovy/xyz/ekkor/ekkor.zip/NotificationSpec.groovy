package xyz.ekkor

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class NotificationSpec extends Specification implements DomainUnitTest<Notification> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
