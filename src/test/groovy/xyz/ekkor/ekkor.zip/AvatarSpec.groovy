package xyz.ekkor

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class AvatarSpec extends Specification implements DomainUnitTest<Avatar> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
